./compile-riscv.sh
./compile-x86.sh