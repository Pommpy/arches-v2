#pragma once
#include "stdafx.hpp"

#include "uvec3.hpp"
#include "vec2.hpp"
#include "vec3.hpp"
#include "vec4.hpp"

#define PI 3.14159265358f

#define T_MAX 4294967296.0f
#define T_MIN 0.00098f;

namespace glm = rtm;

//#define FLT_MAX 3.402823466e+38f
